//export const isAdult = (age) => age >=18;
//export const canDrink = (age) => age >=21;