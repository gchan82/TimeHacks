import React from 'react';
import { BrowserRouter, Route, Switch, Link, NavLink } from 'react-router-dom';


const Header = () => (
    <div>
        <header>
            <h1>Portfolio Site </h1>
        </header>

        <NavLink to="/" activeClassName="is-active" exact={true}>Dashboard</NavLink>
        <NavLink to="/portfolio" activeClassName="is-active" exact={true}>Portfolio Home Page</NavLink>
        <NavLink to="/contact" activeClassName="is-active">contact</NavLink>

    </div>

);


export default Header;