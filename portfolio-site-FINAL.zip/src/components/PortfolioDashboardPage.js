import React from 'react';
import { BrowserRouter, Route, Switch, Link, NavLink } from 'react-router-dom';

const PortfolioDashboardPage = () => (
    <div>PortfolioDashboardPage</div>
);

export default PortfolioDashboardPage;